kats\.detectors\.hourly\_ratio\_detection module
================================================

.. automodule:: kats.detectors.hourly_ratio_detection
    :members:
    :show-inheritance:
