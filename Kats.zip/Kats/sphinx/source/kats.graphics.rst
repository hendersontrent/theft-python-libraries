kats\.graphics package
======================

.. toctree::

    kats.graphics.plots

kats\.graphics module
_____________________

.. automodule:: kats.graphics
    :members:
    :show-inheritance:
