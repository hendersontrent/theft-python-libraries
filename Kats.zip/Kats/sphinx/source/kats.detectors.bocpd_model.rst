kats\.detectors\.bocpd\_model module
====================================

.. automodule:: kats.detectors.bocpd_model
    :members:
    :show-inheritance:
