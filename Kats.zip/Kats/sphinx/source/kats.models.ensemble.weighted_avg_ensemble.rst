kats\.models\.ensemble\.weighted\_avg\_ensemble module
======================================================

.. automodule:: kats.models.ensemble.weighted_avg_ensemble
    :members:
    :show-inheritance:
