kats\.models\.prophet module
============================

.. automodule:: kats.models.prophet
    :members:
    :show-inheritance:
