kats\.detectors\.trend\_mk module
=================================

.. automodule:: kats.detectors.trend_mk
    :members:
    :show-inheritance:
