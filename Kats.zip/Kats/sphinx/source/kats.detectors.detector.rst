kats\.detectors\.detector module
================================

.. automodule:: kats.detectors.detector
    :members:
    :show-inheritance:
