kats\.models\.harmonic\_regression module
=========================================

.. automodule:: kats.models.harmonic_regression
    :members:
    :show-inheritance:
