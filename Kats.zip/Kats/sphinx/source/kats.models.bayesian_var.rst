kats\.models\.bayesian\_var module
==================================

.. automodule:: kats.models.bayesian_var
    :members:
    :show-inheritance:
