kats\.models\.var module
========================

.. automodule:: kats.models.var
    :members:
    :show-inheritance:
