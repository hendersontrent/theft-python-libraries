kats\.models\.quadratic\_model module
=====================================

.. automodule:: kats.models.quadratic_model
    :members:
    :show-inheritance:
