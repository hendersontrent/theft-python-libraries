kats\.models\.theta module
==========================

.. automodule:: kats.models.theta
    :members:
    :show-inheritance:
