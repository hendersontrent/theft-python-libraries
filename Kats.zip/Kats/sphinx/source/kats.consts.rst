kats\.consts module
===================

.. automodule:: kats.consts
    :members:
    :show-inheritance:
