kats\.detectors\.residual\_translation module
=============================================

.. automodule:: kats.detectors.residual_translation
    :members:
    :show-inheritance:
