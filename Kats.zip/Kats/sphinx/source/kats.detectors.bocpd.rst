kats\.detectors\.bocpd module
=============================

.. automodule:: kats.detectors.bocpd
    :members:
    :show-inheritance:
