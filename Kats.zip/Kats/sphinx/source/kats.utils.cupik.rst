kats\.utils\.cupik module
=========================

.. automodule:: kats.utils.cupik
    :members:
    :show-inheritance:
