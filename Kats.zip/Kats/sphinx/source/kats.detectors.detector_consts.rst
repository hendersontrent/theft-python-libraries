kats\.detectors\.detector\_consts module
========================================

.. automodule:: kats.detectors.detector_consts
    :members:
    :show-inheritance:
