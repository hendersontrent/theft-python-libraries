kats\.models\.linear\_model module
==================================

.. automodule:: kats.models.linear_model
    :members:
    :show-inheritance:
