kats\.utils package
===================

.. toctree::

    kats.utils.backtesters
    kats.utils.cupik
    kats.utils.decomposition
    kats.utils.emp_confidence_int
    kats.utils.parameter_tuning_utils
    kats.utils.simulator
    kats.utils.time_series_parameter_tuning

kats\.utils module
__________________

.. automodule:: kats.utils
    :members:
    :show-inheritance:
