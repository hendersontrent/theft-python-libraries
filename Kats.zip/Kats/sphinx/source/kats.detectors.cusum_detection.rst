kats\.detectors\.cusum\_detection module
========================================

.. automodule:: kats.detectors.cusum_detection
    :members:
    :show-inheritance:
