kats\.utils\.decomposition module
=================================

.. automodule:: kats.utils.decomposition
    :members:
    :show-inheritance:
