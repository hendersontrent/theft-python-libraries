kats\.models\.holtwinters module
================================

.. automodule:: kats.models.holtwinters
    :members:
    :show-inheritance:
