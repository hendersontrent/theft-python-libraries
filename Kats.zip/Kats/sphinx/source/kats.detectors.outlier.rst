kats\.detectors\.outlier module
===============================

.. automodule:: kats.detectors.outlier
    :members:
    :show-inheritance:
