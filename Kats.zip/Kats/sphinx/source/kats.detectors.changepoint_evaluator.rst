kats\.detectors\.changepoint\_evaluator module
==============================================

.. automodule:: kats.detectors.changepoint_evaluator
    :members:
    :show-inheritance:
