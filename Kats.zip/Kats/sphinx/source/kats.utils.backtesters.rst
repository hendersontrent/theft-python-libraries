kats\.utils\.backtesters module
===============================

.. automodule:: kats.utils.backtesters
    :members:
    :show-inheritance:
