kats\.detectors\.prophet\_detector module
=========================================

.. automodule:: kats.detectors.prophet_detector
    :members:
    :show-inheritance:
