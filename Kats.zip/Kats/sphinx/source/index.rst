kats
====

.. toctree::

    kats.consts
    kats.detectors
    kats.graphics
    kats.models
    kats.tsfeatures
    kats.utils
